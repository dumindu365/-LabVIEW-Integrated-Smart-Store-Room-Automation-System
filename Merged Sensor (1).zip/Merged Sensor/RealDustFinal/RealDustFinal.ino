// --- Sharp Dust Sensor - Simple 5-Second Hold ---

int measurePin = A5; 
int ledPower = 12;   

int samplingTime = 280;
int deltaTime = 40;
int sleepTime = 9680;

float voMeasured = 0;
float calcVoltage = 0;
float dustDensity = 0;

// --- THRESHOLD & TIMER VARIABLES ---
float dustThreshold = 200.0; // Your requested threshold
unsigned long fanOnTime = 0; // Stopwatch memory
int fanState = 0;            // 0 = OFF, 1 = ON

void setup() {
  // Lock the Baud Rate to 9600 (Must match LabVIEW!)
  Serial.begin(9600);
  pinMode(ledPower, OUTPUT);
}

void loop() {
  // 1. Read the LIVE Sensor Data
  digitalWrite(ledPower, LOW); 
  delayMicroseconds(samplingTime);
  voMeasured = analogRead(measurePin); 
  delayMicroseconds(deltaTime);
  digitalWrite(ledPower, HIGH); 
  delayMicroseconds(sleepTime);

  // 2. Calculate Live Dust
  calcVoltage = voMeasured * (5.0 / 1024.0);
  dustDensity = 0.17 * calcVoltage - 0.1;
  float liveDust = dustDensity * 1000;
  
  // Protect against negative readings
  if (liveDust < 0) { liveDust = 0; }

  // 3. --- SIMPLIFIED 5-SECOND HOLD LOGIC ---
  // If the sensor detects a spike over 200, turn fan ON and restart the 5-sec timer
  if (liveDust > dustThreshold) {
    fanState = 1;
    fanOnTime = millis(); 
  }

  // If the fan is currently ON, check if 5 seconds (5000ms) have safely passed
  if (fanState == 1) {
    if (millis() - fanOnTime >= 5000) {
      fanState = 0; // 5 seconds have passed with clean air, turn fan OFF
    }
  }

  // 4. --- SEND TO LABVIEW ---
  // Outputs format: "DustValue,FanCommand" (e.g., "210.50,1")
  Serial.print(liveDust);
  Serial.print(",");
  Serial.println(fanState);

  // Keep LabVIEW graph updating smoothly
  delay(100); 
}