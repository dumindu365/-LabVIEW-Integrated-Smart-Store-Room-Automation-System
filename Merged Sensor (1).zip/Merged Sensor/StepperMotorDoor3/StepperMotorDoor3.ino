#include <Stepper.h>

// --- 1. Stepper Motor Setup ---
const int stepsPerRevolution = 2048; // Standard for 28BYJ-48
const int travelSteps = 1960;        // Steps needed for your door distance

// Initialize the stepper library on pins 8, 9, 10, 11.
// NOTE: If the motor just vibrates, swap the middle pins to: (stepsPerRevolution, 8, 9, 10, 11)
Stepper myStepper(stepsPerRevolution, 8, 10, 9, 11); 

// --- 2. DAQ Input Setup ---
const int daqPin = 7; // The pin listening to LabVIEW's Master XOR

// --- 3. The "Memory" Variable ---
// This tells the Arduino to assume the door is closed when you first turn it on.
bool isDoorOpen = false; 

void setup() {
  // Set the DAQ pin to listen for the 5V/0V signal
  pinMode(daqPin, INPUT);
  
  // Set motor speed (10 to 15 RPM is usually a good balance of speed and torque)
  myStepper.setSpeed(12); 
  
  Serial.begin(9600);
  Serial.println("System Ready. Waiting for LabVIEW command...");
}

void loop() {
  // 1. Read the live signal coming from LabVIEW via the DAQ
  int daqSignal = digitalRead(daqPin);

  // 2. Scenario A: LabVIEW says "OPEN!" (Signal is HIGH/1)
  if (daqSignal == HIGH && isDoorOpen == false) {
    Serial.println("Opening door...");
    
    // The Arduino will freeze on this line until all 1960 steps are complete
    myStepper.step(travelSteps); 
    
    // Now that it's open, update the memory so it doesn't try to open again
    isDoorOpen = true; 
    Serial.println("Door is OPEN and resting.");
  }
  
  // 3. Scenario B: LabVIEW says "CLOSE!" (Signal is LOW/0)
  else if (daqSignal == LOW && isDoorOpen == true) {
    Serial.println("Closing door...");
    
    // Step backwards (negative number) to close
    myStepper.step(-travelSteps); 
    
    // Now that it's closed, update the memory
    isDoorOpen = false; 
    Serial.println("Door is CLOSED and resting.");
  }

  // A tiny delay to keep the microcontroller loop stable
  delay(50);
}