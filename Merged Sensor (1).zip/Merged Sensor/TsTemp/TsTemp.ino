#include "DHT.h"
#define DHTPIN 2    // Pin donde está conectado el sensor
#define DHTTYPE DHT22    // Sensor DHT22

DHT dht(DHTPIN, DHTTYPE);

void setup() {
    Serial.begin(9600);
    dht.begin();
}

void loop() {
    delay(200);
    float h = dht.readHumidity(); // Leemos la Humedad
    float t = dht.readTemperature(); // Leemos la temperatura en grados Celsius
    //float f = dht.readTemperature(true); // Leemos la temperatura en grados Fahrenheit

    //---Enviamos las lecturas por el puerto serial---
    // Serial.print("Temperatura: ");
    Serial.print(t); // Si se desea utilizar "F es necesario cambiar "t" por "f".
    // Serial.print(" °C ");
    Serial.print(",");
    Serial.println(h);

    // Serial.print("Humedad ");
    // Serial.print(h);
    // Serial.println(" %HR ");

    delay(1000);
}